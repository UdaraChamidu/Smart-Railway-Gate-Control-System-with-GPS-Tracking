#ifndef WIFI_CONNECT_H_
#define WIFI_CONNECT_H_

void wifi_init_sta(void);  // Function to initialize Wi-Fi station

#endif /* WIFI_CONNECT_H_ */