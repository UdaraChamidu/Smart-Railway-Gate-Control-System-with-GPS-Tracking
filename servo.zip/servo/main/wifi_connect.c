#include "wifi_connect.h"
#include "esp_wifi.h"
#include "esp_log.h"
#include "esp_event.h"
#include "nvs_flash.h"

void wifi_init_sta(void) {
    // Your Wi-Fi setup code here
    ESP_LOGI("WiFi", "wifi_init_sta() called");
}